# Pokemon Battle Data

- https://www.kaggle.com/terminus7/pokemon-challenge


# NFL Football Data
Collected from the following website:
- http://www.nfl.com/stats/categorystats?archive=true&conference=null&role=TM&offensiveStatisticCategory=GAME_STATS&defensiveStatisticCategory=null&season=2007&seasonType=REG&tabSeq=2&qualified=false&Submit=Go


# Flatlizard Data
Data collected at Augrabies Falls National Park (South Africa) in September-October 2002, on the contest performance and background attributes of 77 male flat lizards (Platysaurus broadleyi). The results of exactly 100 contests were recorded, along with various measurements made on each lizard. Full details of the study are in Whiting et al. (2006).

http://whitinglab.com/people/martin-whiting/
